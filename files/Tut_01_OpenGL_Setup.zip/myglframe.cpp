#include <QResizeEvent>

#include "myglframe.h"

MyGLFrame::MyGLFrame(QWidget *parent) :
    QGLWidget(parent),
    RenderThread(this)
{
    setAutoBufferSwap(false);
}

MyGLFrame::~MyGLFrame()
{
}

void MyGLFrame::initRenderThread(void)
{
    doneCurrent();
    RenderThread.start();
}

void MyGLFrame::stopRenderThread(void)
{
    RenderThread.stop();
    RenderThread.wait();
}

void MyGLFrame::resizeEvent(QResizeEvent *evt)
{
    RenderThread.resizeViewport(evt->size());
}

void MyGLFrame::paintEvent(QPaintEvent *)
{
    // Do nothing. Let the thread do the work
}

void MyGLFrame::closeEvent(QCloseEvent *evt)
{
    stopRenderThread();
    QGLWidget::closeEvent(evt);
}
