#ifndef MYRENDERTHREAD_H
#define MYRENDERTHREAD_H

#include <QThread>

class MyGLFrame;
class QSize;

class MyRenderThread : public QThread
{
    Q_OBJECT
public:
    explicit MyRenderThread(MyGLFrame *parent = 0);
    void resizeViewport(const QSize &size);
    void run(void);
    void stop(void);

protected:
    void GLInit(void);
    void GLResize(int width, int height);
    void paintGL(void);

private:
    bool doRendering, doResize;
    int w, h, FrameCounter;

    MyGLFrame *GLFrame;

signals:
public slots:
};

#endif // MYRENDERTHREAD_H
